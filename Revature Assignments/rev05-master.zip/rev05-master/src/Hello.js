const Hello = (props) => {
    return (<p>This is from hello component! {props.name}</p>);
}

export default Hello;