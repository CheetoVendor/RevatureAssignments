const ListCount = ({ list }) => {
    return (
        <>
            <h3>Total Elements: {list.length}</h3>
        </>);
}

export default ListCount;